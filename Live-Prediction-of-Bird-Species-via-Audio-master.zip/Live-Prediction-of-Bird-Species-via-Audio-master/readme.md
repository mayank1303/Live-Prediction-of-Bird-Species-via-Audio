## README
>This model still lack of certain coditions, like voice of any other bird or humans or anything other than specified birds voices could be misclassified.
>The acccuracy of this model reaches approximately 55%, which is very low and is due to the dataset collected for this project are very less. 


## Setup:
1. Change locations of files acordingly to the program
2. Install the required packages.
3. DO NOT delete any file.
4. To run the program:
    a. Open terminal
    b. Run python3 main.py
    c. Open the location in chrome or firefox
    d. Explore the program with various birds voices.
 
 

## Group Members
1. [Megha Sharma](https://github.com/m36h4)
2. [Mayank Kumar Rathor](https://github.com/mayank1303)
3. Saloni Sisodiya
